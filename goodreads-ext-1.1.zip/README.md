# Goodreads-ext
### About

Goodreads-ext is an unofficial extension that allows modifications to certain aspects of Goodreads. 
All changes are client-side.

### Roadmap
For now, the roadmap is rather... short. It will grow over time with my usage, feedback from friends who use Goodreads, or requests from you.
 - [ ] Clean the mess in my code (re-organize, optimize, comment and test after modifications)
 - [ ] Option to move editions rating on the left (And replace standard notation)
 - [ ] Stabilization
 - [ ] Theming
 - [ ] ...

### How to ask for a feature
If you have a specific need or request, feel free to ask directly through GitHub issues, if possible. I will also set up a Google Form for those who don't have a GitHub account.
